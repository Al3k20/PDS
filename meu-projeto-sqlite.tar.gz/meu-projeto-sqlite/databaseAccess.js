const sqlite3 = require(&#39;sqlite3&#39;).verbose();
class DatabaseAccess {
  constructor(dbPath) {
    this.db = new sqlite3.Database(dbPath);
  }
  executarComando(query, params = []) {
    return new Promise((resolve, reject) =&gt; {
      this.db.run(query, params, function(err) {
        if (err) reject(err);
        else resolve(this);
      });
    });
  }
  executarConsulta(query, params = []) {
    return new Promise((resolve, reject) =&gt; {
      this.db.all(query, params, (err, rows) =&gt; {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }
}
module.exports = DatabaseAccess;